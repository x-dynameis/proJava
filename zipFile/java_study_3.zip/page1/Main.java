class Main {
  public static void main(String[] args) {
    hello();
  }
  
  public static void hello() {
    // "Hello World"を、"Hello Java"に書き換えてください
    System.out.println("Hello Java");
  }
}
