class Main {
  public static void main(String[] args) {
    // printDataメソッドを呼び出してください
    printData();
    
  }
  
  // printDataメソッドを定義してください
  	public static void printData() {
		System.out.println("私の名前はKate Jonesです");
	}
  
}
