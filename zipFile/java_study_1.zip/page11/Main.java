class Main {
  public static void main(String[] args) {
    int length = 6;
    int height = 8;
    
    // 変数rectangleAreaに、四角形の面積を代入してください
   int rectangleArea = length * height;
    
    // 変数rectangleAreaを出力してください
    System.out.println(rectangleArea);
    
    // 変数triangleAreaに、三角形の面積を代入してください
    int triangleArea = length * height /2;
    
    // 変数triangleAreaを出力してください
    System.out.println(triangleArea);
    
  }
}
