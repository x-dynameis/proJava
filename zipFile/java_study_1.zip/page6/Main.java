class Main {
  public static void main(String[] args) {
    // int型の変数numberを定義してください
    int number;
    
    // 変数numberに3を代入してください
    number = 3;
    
    // 変数numberを出力してください
    System.out.println(number);

    // String型の変数nameを定義してください
    String name;
    
    // 変数nameに"Wanko"を代入してください
    name = "Wanko";
    
    // 変数nameを出力してください
    System.out.println(name);
    
  }
}
