class Main {
  public static void main(String[] args) {
    int month = 12;
    int date = 31;
    
    // 「12月31日」となるように変数と文字列を連結して出力してください
    System.out.println(month + "月" + date + "日");
    
    // 7を2で割った値を出力してください
    System.out.println(7/2);
    
    // 7.0を2.0で割った値を出力してください
    System.out.println(7.0 /2.0);
    
    // 7を2.0で割った値を出力してください
    System.out.println(7 /2.0);
    
  }
}
