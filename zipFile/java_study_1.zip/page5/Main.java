class Main {
  public static void main(String[] args) {
    // "こんにちは"と"世界"を連結して出力してください
    System.out.println("こんにちは" + "世界");
    
    // "38"と"19"を連結して出力してください
    System.out.println("38"+"19");
    
    // 38と19を足して出力してください
    System.out.println(38+19);
    
  }
}

