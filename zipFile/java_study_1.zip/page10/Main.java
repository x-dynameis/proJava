class Main {
  public static void main(String[] args) {
    int number = 8;
    
    // 変数numberに7をかけて、変数numberを上書きしてください
    number *= 7;
    
    // 変数numberを出力してください
    
    System.out.println(number);
    // 変数numberの値に1を足して、変数numberを上書きしてください
    
    number++;
    // 変数numberを出力してください
    System.out.println(number);
    
  }
}
