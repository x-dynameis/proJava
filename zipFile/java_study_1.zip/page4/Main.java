class Main {
  public static void main(String[] args) {
    // 12を3で割った値を出力してください
    System.out.println(12/3);
    
    // 3に6を掛けた値を出力してください
    System.out.println(3*6);
    
    // 8を3で割った時の余りを出力してください
    System.out.println(8%3);
    
  }
}
