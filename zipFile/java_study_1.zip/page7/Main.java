class Main {
  public static void main(String[] args) {
    int number1 = 3;
    
    // int型の変数number2を定義し、7を代入してください
    int number2=7;
    
    // number1 * number2を出力してください
    System.out.println(number1 * number2);
    
    // 変数textに「プログラミングを勉強しよう」を代入してください
    String text = "プログラミングを勉強しよう";
    
    // 「Progateで」と変数textを連結して出力してください
    System.out.println ("Progateで" + text);
    
  }
}
