class Main {
  public static void main(String[] args) {
    int number = 3;
    System.out.println(number);
    
    // 変数numberの値に7を足して、変数numberを上書きしてください
    number += 7;
    
    // 変数numberを出力してください
    System.out.println(number);
      
  }
}
