class Main {
  public static void main(String[] args) {
    // double型の変数number1を定義し、8.5を代入してください。
    double number1 = 8.5;
    
    // double型の変数number2を定義し、3.4を代入してください。
    double number2 = 3.4;
    
    // number1にnumber2を足した値を出力してください
    System.out.println(number1+number2);
    
    // number1からnumber2を引いた値を出力してください
    System.out.println(number1-number2);
    
  }
}
