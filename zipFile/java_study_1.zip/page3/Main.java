class Main {
  public static void main(String[] args) {
    // 数値の17を出力してください
    System.out.println(17);
    
    // 5に3を足した値を出力してください
    System.out.println(5+3);
    
    // 「5 + 3」を文字列として出力してください
    System.out.println("5+3");
    
  }
}
