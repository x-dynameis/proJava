class Main {
  public static void main(String[] args) {
    
    //この文章をコメントにしてください
    
    // 「こんにちは、Java」と出力してください
    System.out.println("こんにちは、Java");
    
  }
}

