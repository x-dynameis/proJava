class Main {
  public static void main(String[] args) {
    // 「4 + 2」と「6」を比較し、falseとなるようにしてください
    System.out.println(4 + 2 < 6);
    
    // 「4 + 2」と「6」を比較し、trueとなるようにしてください
    System.out.println(4+2 >= 6);
    
  }
}
