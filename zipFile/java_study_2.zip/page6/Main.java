class Main {
  public static void main(String[] args) {
    int n = 1;
    
    // switch文を用いて、変数nの値に応じて条件分岐をしてください
    switch(n){
      case 1:
        System.out.println("大吉です");
        break;
      case 2:
        System.out.println("吉です");
        break;
       
    }






  }
}