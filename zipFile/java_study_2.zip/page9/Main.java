class Main {
  public static void main(String[] args) {
    // for文を用いて、繰り返し処理をつくってください
    for(int i=1;i<=10;i++){
      System.out.println(i + "回目のループです");
    }
    
  }
}