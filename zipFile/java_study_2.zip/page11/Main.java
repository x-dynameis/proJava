class Main {
  public static void main(String[] args) {
    // 変数namesに、配列を代入してください
    String[] names={"にんじゃわんこ","ひつじ仙人","ベイビーわんこ"};
    
    // インデックス番号が0の要素を出力してください
    System.out.println(names[0]);
    
    // インデックス番号が2の要素を出力してください
    System.out.println(names[2]);
    
  }
}
