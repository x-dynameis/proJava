class Main {
  public static void main(String[] args) {
    // 「true」を用いて、「真」を表す真偽値を出力してください
    System.out.println(true);
    
    // 「false」を用いて、「偽」を表す真偽値を出力してください
    System.out.println(false);
    
    // 「==」を用いて、値を比較した結果を出力してください
    System.out.println(12 / 4==3);
    
    // 「!=」を用いて、値を比較した結果を出力してください
    System.out.println(12 / 4!=3);
    
    // 変数を定義し、値を比較した結果を代入してください
    boolean bool = 3*9 == 27;
    
    // 変数boolの値を出力してください
    System.out.println(bool);
    
  }
}
