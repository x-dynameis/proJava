public class Person{
  public static String fullName(String firstName,String lastName){
    return firstName + " " + lastName;
  }
  
}