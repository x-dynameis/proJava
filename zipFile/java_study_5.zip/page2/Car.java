// Vehicleクラスを継承してください
class Car extends Vehicle {
  // 以下のコードをVehicleクラスに移動してください

}