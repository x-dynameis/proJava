// Vehicleクラスを継承してください
class Bicycle extends Vehicle{
  // 以下のコードをVehicleクラスに移動してください

  
}