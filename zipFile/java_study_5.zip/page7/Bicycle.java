class Bicycle extends Vehicle {
  // Bicycleクラスのコンストラクタを定義し、
  // superを用いてスーパークラスのコンストラクタを呼び出してください
  public Bicycle(String name,String color){
    super(name,color);
  }
  
}
