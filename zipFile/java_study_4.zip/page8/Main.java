class Main {
  public static void main(String[] args) {
    // newの引数に「Kate Jones」を渡してください
    Person person1 = new Person("Kate Jones");
    person1.hello();
    
    // newの引数に「John Christopher Smith」を渡してください
    Person person2 = new Person("John Christopher Smith");
    person2.hello();
  }
}
