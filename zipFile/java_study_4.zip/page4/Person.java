class Person {
  // インスタンスメソッドhelloを定義してください
  public void hello(){
    System.out.println("こんにちは");
  }
  
}