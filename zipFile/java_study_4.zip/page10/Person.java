class Person {
  // 以下にインスタンスフィールドを定義してください
public String firstName;
public String lastName;
public int age;
public double height;
public double weight;


  // 以下にコンストラクタを定義し、インスタンスフィールドに値をセットしてください
  Person(String firstName,String lastName,int age,double height,double weight){
     this.firstName = firstName;
     this.lastName = lastName;
     this.age = age;
     this.height = height;
     this.weight = weight;
     
  }
  
}
