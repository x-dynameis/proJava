class Main {
  public static void main(String[] args) {
    // Personクラスのインスタンスを生成し、変数person1に代入してください
    Person person1 = new Person();
    
    // Personクラスのインスタンスを生成し、変数person2に代入してください
    Person person2 = new Person();
    
  }
}
