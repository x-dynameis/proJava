// Personクラスを定義してください
public class Person{
  
}